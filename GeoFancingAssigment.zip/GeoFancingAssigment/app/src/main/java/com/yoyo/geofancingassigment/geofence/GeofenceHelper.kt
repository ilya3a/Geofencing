package com.yoyo.geofancingassigment.geofence

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.maps.model.LatLng
import com.yoyo.geofancingassigment.GeofenceReceiver
import com.yoyo.geofancingassigment.utils.SingletonHolder

class GeofenceHelper private constructor(private val context: Context) {
    companion object : SingletonHolder<GeofenceHelper, Context>(::GeofenceHelper) {
        private const val DWELL_THRESHOLD: Int = 3000
    }

    private var pendingIntent: PendingIntent? = null

    fun getGeofenceRequest(geofence: Geofence): GeofencingRequest {
        return GeofencingRequest.Builder()
            .addGeofence(geofence)
            .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_EXIT)
            .build()
    }

    fun getGeofence(id: String, latLng: LatLng, radius: Float, transitionTypes: Int): Geofence {
        return Geofence.Builder()
            .setCircularRegion(latLng.latitude, latLng.longitude, radius)
            .setRequestId(id)
            .setTransitionTypes(transitionTypes)
            .setLoiteringDelay(DWELL_THRESHOLD)
            .setExpirationDuration(Geofence.NEVER_EXPIRE)
            .build()
    }

    fun getPendingIntent(): PendingIntent {
        if (pendingIntent != null) {
            return pendingIntent as PendingIntent
        }
        val intent = Intent(context, GeofenceReceiver::class.java)
        pendingIntent = PendingIntent.getBroadcast(context, 111, intent, PendingIntent.FLAG_UPDATE_CURRENT)
        return pendingIntent as PendingIntent
    }
}