package com.yoyo.geofancingassigment.ui

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.Geofence.GEOFENCE_TRANSITION_ENTER
import com.google.android.gms.location.Geofence.GEOFENCE_TRANSITION_EXIT
import com.yoyo.geofancingassigment.databinding.ActivityMapsBinding

import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.location.GeofencingClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.CircleOptions
import com.google.android.gms.maps.model.MarkerOptions
import com.yoyo.geofancingassigment.R
import com.yoyo.geofancingassigment.geofence.GeofenceHelper
import java.sql.Timestamp

class MapsActivity : AppCompatActivity(), OnMapReadyCallback, LocationSource.OnLocationChangedListener {

    companion object {
        private const val FINE_LOCATION_REQ_CODE = 1001
        private const val GEOFENCE_RADIUS = 300f
    }

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private lateinit var geofencingClient: GeofencingClient
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var mapActivityViewModel: MapsViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        mapActivityViewModel = ViewModelProvider(this).get(MapsViewModel::class.java)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        geofencingClient = LocationServices.getGeofencingClient(this)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        showUserLocation()

    }

    private fun showUserLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            mMap.isMyLocationEnabled = true
            fusedLocationClient.lastLocation
                .addOnSuccessListener { location ->
                    updateMapCamera(location)
                    if (mapActivityViewModel.isFirstLaunch()) {
                        //set that was first launch and deploy 300m geofence
                        mapActivityViewModel.setWasFirstLaunch()
                        addGeofence(location.latitude, location.longitude, GEOFENCE_RADIUS)
                    }
                }
                .addOnFailureListener {
                    Toast.makeText(this, "failed get current location", Toast.LENGTH_SHORT).show()
                }
        } else {
            //ask for permission
            askForLocationPermission()
        }
    }

    private fun addGeofence(latitude: Double, longitude: Double, geofenceRadius: Float) {
        addMarker(latitude, longitude)
        addCircle(latitude, longitude, geofenceRadius)
        val geofenceHelper = GeofenceHelper.getInstance(this)
        val id = (System.currentTimeMillis() / 1000).toString()
        val geofence = geofenceHelper.getGeofence(
            id, LatLng(latitude, longitude), geofenceRadius,
            GEOFENCE_TRANSITION_ENTER or GEOFENCE_TRANSITION_EXIT
        )
        val geofencingRequest = geofenceHelper.getGeofenceRequest(geofence)
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return
        }
        geofencingClient.addGeofences(geofencingRequest,geofenceHelper.getPendingIntent())
            .addOnSuccessListener {  }
            .addOnFailureListener {  }

    }

    private fun addCircle(latitude: Double, longitude: Double, geofenceRadius: Float) {
        val circle = CircleOptions()
            .center(LatLng(latitude, longitude))
            .radius(geofenceRadius.toDouble())
            .strokeColor(Color.argb(200, 0, 255, 0))
            .strokeWidth(3f)
            .fillColor(Color.argb(64, 0, 255, 0))
        mMap.addCircle(circle)
    }

    private fun addMarker(latitude: Double, longitude: Double) {
        val marker = MarkerOptions()
            .position(LatLng(latitude, longitude))
        mMap.addMarker(marker)
    }

    private fun askForLocationPermission() {
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), FINE_LOCATION_REQ_CODE)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            FINE_LOCATION_REQ_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //user gave permission
                    Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Dear user: if you want to use this app you must give location Permission", Toast.LENGTH_LONG).show()
                }
                showUserLocation()
            }
        }


    }

    override fun onLocationChanged(location: Location) {
        updateMapCamera(location)
    }

    private fun updateMapCamera(location: Location) {
        val myLocation = LatLng(location.latitude, location.longitude)
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(myLocation, 16f))
    }

}