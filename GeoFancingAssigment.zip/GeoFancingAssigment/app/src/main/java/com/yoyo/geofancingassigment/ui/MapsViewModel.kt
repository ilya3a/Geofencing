package com.yoyo.geofancingassigment.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.yoyo.geofancingassigment.database.DatabaseHelper

class MapsViewModel(application: Application):AndroidViewModel(application) {
    private val context = application
    private val databaseHelper = DatabaseHelper.getInstance(context)



    fun isFirstLaunch(): Boolean {
        return databaseHelper.isFirstLaunch()
    }

    fun setWasFirstLaunch() {
        databaseHelper.setFirstLaunch()
    }



}