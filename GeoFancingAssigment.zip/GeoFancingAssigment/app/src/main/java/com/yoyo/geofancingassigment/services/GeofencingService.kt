package com.yoyo.geofancingassigment.services

class GeofencingService {
}